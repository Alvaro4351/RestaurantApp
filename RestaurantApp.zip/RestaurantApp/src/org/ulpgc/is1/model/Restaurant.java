package org.ulpgc.is1.model;

public class Restaurant {
}
