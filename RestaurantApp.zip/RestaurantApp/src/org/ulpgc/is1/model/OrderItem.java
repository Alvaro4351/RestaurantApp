package org.ulpgc.is1.model;

public class OrderItem {
    public int quantity;

    public OrderItem(int quantity) {
        this.quantity = quantity;

    }
}